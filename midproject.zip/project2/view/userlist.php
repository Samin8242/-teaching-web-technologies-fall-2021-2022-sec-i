<?php 
 //include('header.php');
	require_once('../controller/header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User list</title>
</head>
<body>
<h1 style="height:80px;background-color:Tomato;text-align: right; word-spacing: 15px;">
		 	<a href="Home.php" style="color: white; ">Home</a>
		 	<a href="About.php" style="color: white;">About</a>
		 	<a href="Contact.php" style="color: white;">Contact</a>
		 	<a href="../controller/LogOut.php" style="color:white;">LogOut</a>
		</h1>
		<a href="adminhomepage.php"> Back </a> | 
		<a href="../controller/logout.php"> logout </a>
		<br>
		<table border="1">
			<tr>
				<th>ID</th>
				<th>NAME</th>
				<th>PASSWORD</th>
                <th>Email</th>
				<th>DOB</th>             
                <th>Gender</th>
				<th>Address</th>
				<th>ACTION</th>
			</tr>

			<?php 
				/*$file = fopen('../model/user.txt', 'r');
				while(!feof($file)){
					$user = fgets($file);
					$user = explode("|", $user);
					//print_r($user);
					if(count($user) > 1){*/
			  $conn = mysqli_connect('localhost', 'root', '', 'tours_and_travel');
              $sql = "select * from users";
              $result = mysqli_query($conn, $sql);
     
    while($row= mysqli_fetch_assoc($result)){
		
    
			?>
			

			<tr>
			    <th><?php echo $row['id']; ?></th>
				<th><?php echo $row['name']; ?></th>
				<th><?php echo $row['password']; ?></th>
				<th><?php echo $row['email']; ?></th>
				<th><?php echo $row['dob']; ?></th>	
				<th><?php echo $row['gender']; ?></th>
				<th><?php echo $row['address']; ?></th>

				
				<td>
					<a class="btn btn-info" href="edituser.php?id=<?php echo $row['id']; ?>">Edit</a>&nbsp;
				    <a class="btn btn-danger" href="userDelete.php?id=<?php echo $row['id']; ?>">Delete</a>
			   </td>
			</tr>

			<?php
		}
				
			?>
		</table>
</body>
</html>