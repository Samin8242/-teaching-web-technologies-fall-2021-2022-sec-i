<?php 

	$PLACE = $_REQUEST['PLACE'];
	$HOTALENAME = $_REQUEST['HOTALENAME'];
	$ROOMAVAILABLE = $_REQUEST['ROOMAVAILABLE'];
	
	if ($PLACE == null || $HOTALENAME == null || $ROOMAVAILABLE == null) {
		echo "<h1 align= center> PLEASE ADD INFORMATION <br>";
	}else{
		$data = $PLACE."|".$HOTALENAME."|".$ROOMAVAILABLE."\r\n";
		$file = fopen('../model/hotale.txt', 'a');
		fwrite($file, $data);

		echo "<h1 align= center> NEW HOTALE ADDED SUCCESSFULLY <h1/>";
	}



?>


<br/>
<div align="center"><a href="hotale.php"> BACK </a></div>
</body>
</html>