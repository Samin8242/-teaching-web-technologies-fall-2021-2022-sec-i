<!DOCTYPE html>
<html>
    <body>

    <h1 style="height:80px;background-color:Tomato;text-align: right; word-spacing: 15px;">
		 	<a href="Home.php" style="color: white; ">Home</a>
		 	<a href="About.php" style="color: white;">About</a>
		 	<a href="Contact.php" style="color: white;">Contact</a>
		 	<a href="../controller/LogOut.php" style="color:white;">LogOut</a>
		</h1>
        <form>
        <fieldset>
            <table>
                <td><img src="../model/labbugkella.jpg" alt="labbugkella" width="200" height="150"><br></td>
                <td><img src="../model/mohastangor.jpg" alt="mohastangor" width="200" height="150"><br></td>
                <td><img src="../model/sudhrbon.jpg" alt="sudhrbon" width="200" height="150"><br></td>
                <td><img src="../model/Sajek.jpg" alt="Sajek" width="200" height="150"><br></td>  
                <td><img src="../model/Sylhet.jpg" alt="Sylhet" width="200" height="150"><br></td>   
                <td><img src="../model/Sajek.jpg" alt="Sajek" width="200" height="150"><br></td>  
                <td><img src="../model/Sylhet.jpg" alt="Sylhet" width="200" height="150"><br></td>   
            </table>
            <table>
                <td><img src="../model/labbugkella.jpg" alt="labbugkella" width="200" height="150"><br></td>
                <td><img src="../model/mohastangor.jpg" alt="mohastangor" width="200" height="150"><br></td>
                <td><img src="../model/sudhrbon.jpg" alt="sudhrbon" width="200" height="150"><br></td>
                <td><img src="../model/Sajek.jpg" alt="Sajek" width="200" height="150"><br></td>  
                <td><img src="../model/Sylhet.jpg" alt="Sylhet" width="200" height="150"><br></td>     
            </table>
        </fieldset>
        </form>
        <a href="userhomepage.php" >Back</a>
    </body>
</html>