<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home Page</title>
</head>
<body>
<h1 style="height:80px;background-color:Tomato;text-align: right; word-spacing: 15px;">
		 	
		 	<a href="About.php" style="color: white;">About</a>
		 	<a href="Contact.php" style="color: white;">Contact</a>
		 	<a href="../controller/LogOut.php" style="color:white;">LogOut</a>
		</h1>
    <form action="../controller/regCheck.php" method="post" enctype="">
    <form action="../controller/Search.php" method="get" enctype="">
        <fieldset style="background-color:DodgerBlue;">
            <h1>Tours and Travel Management System</h1>
            
            <table>
                <tr>
                    <td>Search </td>
                    <td><input type="text" name="search" value=""></td>
                    <td><button type="submit">Search</button></td>
                </tr>
                <tr>
                    <td><a href="viewGallery.php"> View Gallery </a> <br></td>
                </tr>
            </table>
        </fieldset>
        </from>
        <table>
            <td>
                <img src="../model/sudhrbon.jpg" alt="sudhrbon" width="200" height="150"><br>
                <a href="sundarban.php"> Sundarban </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 2 hoteles </a> <br>

            </td>
            <td>
                <img src="../model/labbugkella.jpg" alt="labbugkella" width="200" height="150"><br>
                <a href="../view/signup.php"> labbugkella </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 10 hoteles </a> <br>
            </td>
            <td>
                <img src="../model/mohastangor.jpg" alt="mohastangor" width="200" height="150"><br>
                <a href="../view/signup.php"> mohastangor</a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 15 hoteles </a> <br>
            </td>
            <td>
                <img src="../model/Sajek.jpg" alt="Sajek" width="200" height="150"><br>
                <a href="sajek.php"> Sajek </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 5 hoteles </a> <br>
            </td>
            <td>
                <img src="../model/Sylhet.jpg" alt="Sylhet" width="200" height="150"><br>
                <a href="../view/signup.php"> Sylhet </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 3 hoteles </a> <br>
            </td>
        </table>
        <table>
            <td>
                <img src="../model/sudhrbon.jpg" alt="sudhrbon" width="200" height="150"><br>
                <a href="../view/signup.php"> Sudhrbon </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 2 hoteles </a> <br>

            </td>
            <td>
                <img src="../model/labbugkella.jpg" alt="labbugkella" width="200" height="150"><br>
                <a href="../view/signup.php"> labbugkella </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 10 hoteles </a> <br>
            </td>
            <td>
                <img src="../model/mohastangor.jpg" alt="mohastangor" width="200" height="150"><br>
                <a href="../view/signup.php"> mohastangor</a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 15 hoteles </a> <br>
            </td>
            <td>
                <img src="../model/Sajek.jpg" alt="Sajek" width="200" height="150"><br>
                <a href="../view/signup.php"> Sajek </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 5 hoteles </a> <br>
            </td>
            <td>
                <img src="../model/Sylhet.jpg" alt="Sylhet" width="200" height="150"><br>
                <a href="../view/signup.php"> Sylhet </a> <br>
                <p>Budget Friendly Travel, <br> Cleanliness, Friendly Locals</p>
                <a href="../view/signup.php"> 3 hoteles </a> <br>
            </td>
        </table>	
    </form>
</body>
</html>