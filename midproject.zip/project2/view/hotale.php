<!DOCTYPE html>
<html>
<head>
	
	<title>HOTALE</title>
</head>
<body>
	<h2 align="center">MANGE HOTALES</h2>

	<table align="center">
<?php

header("Content-type: text/html");

$file = fopen("../model/hotale.txt","r");

?>

<table align="center" border="2px" cellpadding="2px" cellspacing="4px">

<tr>

<th>SERIAL NO</th>

<th>PLACE</th>

<th>HOTALE NAME</th>

<th>ROOM AVAILABLE </th>



</tr>

<?php
$i=0;
while(($row = fgets($file)) != false) {
	 echo "<tr>";

$col = explode('|',$row);
echo "<td>". $i."</td>";
foreach($col as $data) {

echo "<td>". trim($data)."</td>";

}
echo "</tr>";
$i++;
}

?>

	</table>
	<form action="addhotale.php" method="post" enctype="">

			<fieldset >
				<legend>ADD NEW HOTALE</legend>
				<table align="center">
					<tr>
						<td>PLACE</td>
						<td><input type="text" name="PLACE" value=""></td>
					</tr>
					<tr>
						<td>HOTALE NAME</td>
						<td><input type="text" name="HOTALENAME" value=""></td>
					</tr>
					<tr>
						<td>ROOM AVAILABLE</td>
						<td><input type="text" name="ROOMAVAILABLE" value=""></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" name="" value="ADD"></td>
					</tr>
				</table>

			</fieldset>

		</form>
		</table>

	<form action="delethotale.php" method="post" enctype="">
		
			<fieldset >
				<legend> DELET HOTALE</legend>
				<table align="center">
					<tr>
						<td>SERIAL</td>
						<td><input type="text"  name="SERIAL" value=""></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" name="" value="DELET"></td>
					</tr>
				</table>

			</fieldset>

		</form>
		<form action="updatehotale.php" method="post" enctype="">
		
			<fieldset >
				<legend>UPDATE HOTALE</legend>
				<table align="center">
					<tr>
						<td>SERIAL</td>
						<td><input type="text"  name="SERIAL" value=""></td>
					</tr>
					<tr>
						<td>PLACE</td>
						<td><input type="text" name="PLACE" value=""></td>
					</tr>
					<tr>
						<td>HOTALE NAME</td>
						<td><input type="text" name="HOTALENAME" value=""></td>
					</tr>
					<tr>
						<td>ROOM AVAILABLE</td>
						<td><input type="text" name="ROOMAVAILABLE" value=""></td>
					</tr>
					
					<tr>
					<tr>
						<td></td>
						<td><input type="submit" name="" value="UPDATE"></td>
					</tr>
				</table>

			</fieldset>

		</form>
 <br>
 <a href="hotalhome.html"> Back to home </a>
</body>
</html>