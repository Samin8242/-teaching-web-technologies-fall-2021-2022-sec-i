<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1 style="height:80px;background-color:Tomato;text-align: right; word-spacing: 15px;">
		 	<a href="adminhomepage.php" style="color: white; ">Back</a>
		 	<a href="About.php" style="color: white;">About</a>
		 	<a href="Contact.php" style="color: white;">Contact</a>
		 	<a href="../controller/LogOut.php" style="color:white;">LogOut</a>
		</h1>


		<?php
         if(isset($_FILES['image'])){

			$file_name = $_FILES['image']['name'];
			$file_size = $_FILES['image']['size'];
			$file_tmp = $_FILES['image']['tmp_name'];
			$file_type = $_FILES['image']['type'];

			if(move_uploaded_file($file_tmp, "view/". $file_name))
			{
				echo "Successfully Uploded";
			}
			else
			{
				echo "Uploded Failed";
			}
		 }
		?>
		

		<form method="post" action="" enctype="multipart/form-data">
		Image: <input type="file" name="myfile" value="">
		<input type="submit" name="submit" value="upload">
	</form>



</body>
</html>