<?php 
	session_start();
	
	if(isset($_REQUEST['update'])){
		$username = $_REQUEST['username'];
		$dob=$_REQUEST['dob'];
		$password = $_REQUEST['password'];
		$email = $_REQUEST['email'];
		$gender = $_REQUEST['gender'];
		$id = $_REQUEST['id'];

		if($username != null && $dob != null && $password != null && $email != null && $gender != null ){
			
			$file = fopen('../model/user.txt', 'r');
			$updatedContent = "";

			while(!feof($file)){
				$line = fgets($file);
				$user = explode('|', $line);
				
				if($user[0] == $id){
					$line = $id."|".$username."|".$password."|".$email."|".$dob."|".$gender."\r\n";
					//$updatedContent .= $line;
				}
				$updatedContent .= $line;
				
			}

			$file = fopen('../model/user.txt', 'w');
			fwrite($file, $updatedContent);
			header('location: ../view/userlist.php');

		}else{
			echo "null submission";
		}
	}
?>